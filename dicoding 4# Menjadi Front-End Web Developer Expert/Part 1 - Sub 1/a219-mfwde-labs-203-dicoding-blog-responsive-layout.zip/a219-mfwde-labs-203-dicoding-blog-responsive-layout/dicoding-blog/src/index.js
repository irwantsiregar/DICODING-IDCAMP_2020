import './styles/main.css';
import './styles/responsive.css';
