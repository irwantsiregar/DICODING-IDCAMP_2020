import './assets/styles/style.css';
import main from "./assets/script/view/main";

main();