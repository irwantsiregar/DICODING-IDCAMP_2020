export class Toolbar {
    constructor(appName, navigations) {
        this.appName = appName;
        this.navigations = navigations
    }
}