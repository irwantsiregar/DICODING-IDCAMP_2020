class Hoaxy {
    constructor(canonicalUrl, datePublished, domain, id, numberOfTweets, score, siteType, title) {
        this.canoncialUrl = canonicalUrl;
        this.datePublished = datePublished;
        this.domain = domain;
        this.id = id;
        this.numberOfTweets = numberOfTweets;
        this.score = score;
        this.siteType = siteType;
        this.title = title;
    }
}

export default Hoaxy;