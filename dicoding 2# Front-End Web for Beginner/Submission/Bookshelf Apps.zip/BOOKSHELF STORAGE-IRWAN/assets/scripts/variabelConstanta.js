let books = [];
const STORAGE_KEY = 'LITERACY_APPS';
const BOOK_ITEMID = 'bookId';
const NOTFINISHED_LIST_BOOK_ID = 'notFinishedReading';
const FINISHED_LIST_BOOK_ID = 'finishedReading'; 

const notFinishedBookList = document.getElementById(NOTFINISHED_LIST_BOOK_ID);
const finishedBookList = document.getElementById(FINISHED_LIST_BOOK_ID);
