export class Movie {
    constructor(id, title, overview, backdrop) {
        this.id = id;
        this.title = title;
        this.overview = overview;
        this.backdrop = backdrop;
    }
}