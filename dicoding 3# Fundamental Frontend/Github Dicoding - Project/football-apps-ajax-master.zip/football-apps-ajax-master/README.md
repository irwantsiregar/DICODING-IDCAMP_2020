Repository ini merupakan bahan latihan dari artikel:

Silakan Anda clone dan kerjakan latihannya pada fungsi getTeam di dalam js/app.js
